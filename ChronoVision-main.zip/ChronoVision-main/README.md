# ChronoVision
ChronoVision is an advanced image recognition system designed to predict the age of individuals from given images. Utilizing the power of Convolutional Neural Networks (CNNs) and implemented in Python with OpenCV, this project delivers accurate age predictions by analyzing facial features.
# Link for Datasets:
https://drive.google.com/drive/folders/12jXKdXJU-VJVI5CGbJra7KbRWqxOE1YB?usp=sharing
